# lab7
- Login screen with basic authentication
- Student list view with sorting and filtering
- Add/Edit student information
- Detailed student view
- Menu system for navigation
